<?php
//inserir google ad-sense aqui



?>
</div>
<footer id="footer" class="footer bordaroxa" style="background-color:black; height:50px;">
<div class="container text-center">
<p class="text-muted" style="color:white;">Essencia do prazer | 2015 - Todos os direitos reservados. Desenvolvido por <a href="http://www.pauloxavier.com" style="color:#7f4098">Paulo Xavier.</a></p></footer>
</div>
</div>
</body>
</html>