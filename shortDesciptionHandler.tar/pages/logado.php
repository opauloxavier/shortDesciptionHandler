<div class="col-md-5 pull-right">
					Bem vindo, <span style="color:#7f4098"><?php echo $_SESSION['nome']; ?></span><div class="col-md-2 pull-right text-center" style="color:#C21952;"><a style="color:#C21952;" href="<?php echo BASE_URL;?>logout"><span class="glyphicon glyphicon-off" aria-hidden="true"> Sair</span></a>
					</div>
					</div>