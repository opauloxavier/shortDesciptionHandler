<?php if( !isset($_SESSION) ){ session_start(); }
	changeDB(); 
?>