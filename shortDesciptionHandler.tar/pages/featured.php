<div class="col-md-12 row temp-featured img-responsive">
	<?php include_once PAGES_URL."status.php";?>
</div>