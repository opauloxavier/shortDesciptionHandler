<?php
	geraPdf();
?>