<?php
		if(isset($_POST['submit']))
		{
		   //$error=check_double($_POST["email"]);
		} 


		areaCadastro($_SESSION['logado']);
?>

