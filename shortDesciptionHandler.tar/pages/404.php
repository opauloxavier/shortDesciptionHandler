<?php

echo "Erro 404 - Erro Maneiro, Erro Sangue Bom.";

?>