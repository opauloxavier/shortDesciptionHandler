<div class="col-md-12 bordaroxa temp-coelho img-responsive">
				<div class="col-md-12">
				<div class="col-md-4 col-md-offset-3">
					<h3>Cadastre-se,indique seus amigos e concorra a um <span class="rosa">Rabbit!</span></h3>
				</div>

				<div class="col-md-12">
					<form class="form-horizontal" method="POST" action="<?php echo BASE_URL; ?>index.php" id="formCadastro" name="formCadastro">
					  <div class="form-group">
					    <div class="col-md-4 col-md-offset-3">
					      <input type="text" class="form-control" id="nome" name="nomeCadastro" placeholder="Nome" required="true">
					    </div>
					  </div>

					  <div class="form-group">
					    <div class="col-md-4 col-md-offset-3">
					      <input type="email" class="form-control" id="email" name="emailCadastro" placeholder="Email" required="true">
					    </div>
					  </div>
					  <div class="form-group">
					    <div class="col-md-4 col-md-offset-3">
					      <input type="password" class="form-control" id="inputPassword3" name="passwordCadastro" placeholder="Senha" required="true">
					    </div>
					  </div>
					  <div class="form-group">
					    <div class="col-md-4 col-md-offset-3">
					      <button type="submit" name="submitCadastro" class="btn btn-lg btn-custom btn-block">CADASTRAR!</button>
					    </div>
					  </div>
					</form>
				</div>
				</div>
				</div>